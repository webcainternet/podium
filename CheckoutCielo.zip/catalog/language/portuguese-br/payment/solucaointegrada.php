<?php
/* ------------------------------------------------------------------------------
Módulo:             Solução Integrada - Cielo
Versão:             1.00
Autor:              MSE Informática - www.msebrasil.com.br - Tel.: (18) 3841-1352
Compatibilidade:    Opencart 1.5.6.X
------------------------------------------------------------------------------ */

require_once(DIR_SYSTEM . 'library/solucaointegrada.php');
$mse = new MSE(MID);
eval($mse->show('mT622twZkVXeNEUwrPOgFxKgaRRDHc1MZxnrASTdbl2BkKv6tmPNF2Ca2YJWViJAUNy2vXWkIjb5N3si2dKYFmQnvTO15NM6FrhUKuvCPAYfUpWPadJrLOzUxt20ETrEvRp2EZciDIJdi6eMHMbJXqjWWQPtodBH26XIvqXdL9J3vqucYVS19Yyxk-e8tWZAv7PWrVFtjc5Cte2tfMNAMQ,,'));
?>